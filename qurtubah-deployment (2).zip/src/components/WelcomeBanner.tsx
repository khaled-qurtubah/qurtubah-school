'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { useAppStore } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { X, ClipboardList, CheckCircle2, Clock, Building2, Plus, FileText, BarChart3, TrendingUp, Users, ChevronLeft } from 'lucide-react'
import type { TabId } from '@/lib/types'

interface StatsData {
  total: number
  completed: number
  inProgress: number
  departments: number
  avgProgress: number
}

const STORAGE_KEY = 'welcome-banner-dismissed'

function useAnimatedNumber(target: number, duration: number = 800): number {
  const [current, setCurrent] = useState(0)
  const rafRef = useRef<number>()

  useEffect(() => {
    const start = performance.now()
    const animate = (now: number) => {
      const elapsed = now - start
      const progress = Math.min(elapsed / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3)
      setCurrent(Math.round(target * eased))
      if (progress < 1) {
        rafRef.current = requestAnimationFrame(animate)
      }
    }
    rafRef.current = requestAnimationFrame(animate)
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current) }
  }, [target, duration])

  return current
}

function StatCard({ icon: Icon, label, value, color, bg, delay }: {
  icon: React.ElementType
  label: string
  value: number
  color: string
  bg: string
  delay: number
}) {
  const animated = useAnimatedNumber(value, 800 + delay * 150)
  return (
    <div className={`animate-stagger-${delay + 1} flex items-center gap-3 rounded-xl bg-white/80 dark:bg-gray-900/60 backdrop-blur-sm border border-white/90 dark:border-gray-700/50 p-3.5 transition-all duration-300 hover:shadow-lg hover:shadow-emerald-900/5 dark:hover:shadow-emerald-900/20 hover:scale-[1.03] hover:bg-white dark:hover:bg-gray-800/60 group`}
      >
      <div className={`size-11 rounded-xl flex items-center justify-center ${bg} transition-all duration-300 group-hover:scale-110 group-hover:rotate-3`}>
        <Icon className={`size-5 ${color} transition-transform duration-300 group-hover:scale-110`} />
      </div>
      <div className="min-w-0">
        <p className="text-[11px] text-gray-500 dark:text-gray-400 font-medium">{label}</p>
        <p className={`text-xl font-extrabold ${color} tabular-nums leading-tight`}>
          {animated.toLocaleString('ar-SA')}
        </p>
      </div>
    </div>
  )
}

const quickActions = [
  { label: 'إضافة برنامج', icon: Plus, tab: 'programs' as TabId, color: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-emerald-50 dark:bg-emerald-900/20 border-emerald-200/60 dark:border-emerald-800/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/40' },
  { label: 'التقارير', icon: FileText, tab: 'reports' as TabId, color: 'text-blue-600 dark:text-blue-400', bg: 'bg-blue-50 dark:bg-blue-900/20 border-blue-200/60 dark:border-blue-800/40 hover:bg-blue-100 dark:hover:bg-blue-900/40' },
  { label: 'الإحصائيات', icon: BarChart3, tab: 'statistics' as TabId, color: 'text-purple-600 dark:text-purple-400', bg: 'bg-purple-50 dark:bg-purple-900/20 border-purple-200/60 dark:border-purple-800/40 hover:bg-purple-100 dark:hover:bg-purple-900/40' },
  { label: 'الموظفين', icon: Users, tab: 'employees' as TabId, color: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-50 dark:bg-amber-900/20 border-amber-200/60 dark:border-amber-800/40 hover:bg-amber-100 dark:hover:bg-amber-900/40' },
  { label: 'الأهداف', icon: TrendingUp, tab: 'goals' as TabId, color: 'text-teal-600 dark:text-teal-400', bg: 'bg-teal-50 dark:bg-teal-900/20 border-teal-200/60 dark:border-teal-800/40 hover:bg-teal-100 dark:hover:bg-teal-900/40' },
]

export default function WelcomeBanner() {
  const { filters, setActiveTab } = useAppStore()
  const [dismissed, setDismissed] = useState(false)
  const [stats, setStats] = useState<StatsData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setDismissed(localStorage.getItem(STORAGE_KEY) === 'true')
  }, [])

  const fetchStats = useCallback(async () => {
    try {
      const [statsRes, deptsRes] = await Promise.all([
        fetch(`/api/stats?year=${filters.year}`),
        fetch('/api/departments'),
      ])
      if (statsRes.ok) {
        const statsJson = await statsRes.json()
        const statsData = statsJson.data
        let deptCount = 0
        if (deptsRes.ok) {
          const deptsJson = await deptsRes.json()
          deptCount = (deptsJson.data || []).length
        }
        setStats({
          total: statsData.total || 0,
          completed: statsData.completed || 0,
          inProgress: statsData.inProgress || 0,
          departments: deptCount,
          avgProgress: statsData.avgProgress || 0,
        })
      }
    } catch { /* silent */ } finally {
      setLoading(false)
    }
  }, [filters.year])

  useEffect(() => {
    if (!dismissed) fetchStats()
  }, [dismissed, fetchStats])

  const handleDismiss = () => {
    setDismissed(true)
    localStorage.setItem(STORAGE_KEY, 'true')
  }

  if (dismissed) return null

  return (
    <div className="relative overflow-hidden rounded-2xl p-5 sm:p-6 mb-6 animate-slide-in-up gradient-border">
      {/* Backgrounds with animated gradient */}
      <div className="absolute inset-0 rounded-2xl" style={{
        background: 'linear-gradient(135deg, #ecfdf5 0%, #f0fdfa 25%, #f0f9ff 50%, #faf5ff 75%, #fdf2f8 100%)',
      }} />
      <div className="absolute inset-0 bg-gradient-to-br from-emerald-950/30 via-teal-950/15 to-purple-950/20 dark:block hidden rounded-2xl animate-gradient-x" style={{ backgroundSize: '200% 200%' }} />

      {/* Decorative elements with floating animation */}
      <div className="absolute -top-12 -right-12 w-40 h-40 rounded-full bg-emerald-300/20 dark:bg-emerald-700/10 blur-3xl animate-float" />
      <div className="absolute -bottom-10 -left-10 w-48 h-48 rounded-full bg-teal-300/15 dark:bg-teal-700/10 blur-3xl animate-float-alt" />
      <div className="absolute top-1/2 left-1/3 w-32 h-32 rounded-full bg-purple-300/10 dark:bg-purple-700/10 blur-3xl animate-float-slow" />
      <div className="absolute inset-0 dot-pattern opacity-20 rounded-2xl" />

      {/* Dismiss button */}
      <Button
        variant="ghost"
        size="icon"
        onClick={handleDismiss}
        className="absolute top-3 left-3 size-7 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 hover:bg-white/70 dark:hover:bg-white/10 z-10 rounded-lg"
        aria-label="إغلاق البانر"
      >
        <X className="size-3.5" />
      </Button>

      <div className="relative z-10">
        {/* Title row */}
        <div className="flex items-start justify-between mb-5 gap-4">
          <div className="min-w-0">
            <h2 className="text-lg sm:text-xl font-extrabold text-gray-800 dark:text-white mb-0.5 flex items-center gap-2">
              <span className="gradient-text">مرحباً بك في نظام إدارة البرامج</span>
            </h2>
            <p className="text-sm text-gray-600/80 dark:text-gray-300/80">
              لوحة التحكم الشاملة لإدارة ومتابعة البرامج والأنشطة المدرسية
            </p>
          </div>
          <div className="hidden sm:flex items-center gap-1.5 text-xs text-gray-400 dark:text-gray-500 bg-white/60 dark:bg-gray-800/40 backdrop-blur-sm rounded-lg px-3 py-2 border border-white/80 dark:border-gray-700/40">
            <kbd className="pointer-events-none inline-flex h-5 select-none items-center rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 px-1.5 font-mono text-[10px] font-medium">?</kbd>
            <span>اختصارات</span>
            <span className="mx-0.5 text-gray-300 dark:text-gray-600">|</span>
            <kbd className="pointer-events-none inline-flex h-5 select-none items-center rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 px-1.5 font-mono text-[10px] font-medium">Ctrl+K</kbd>
            <span>بحث</span>
          </div>
        </div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-5">
          {loading ? (
            Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3 rounded-xl bg-white/70 dark:bg-gray-900/50 backdrop-blur-sm border border-white/80 dark:border-gray-700/50 p-3.5">
                <Skeleton className="size-11 rounded-xl" />
                <div className="space-y-2">
                  <Skeleton className="h-3 w-14" />
                  <Skeleton className="h-5 w-8" />
                </div>
              </div>
            ))
          ) : stats ? (
            <>
              <StatCard icon={ClipboardList} label="إجمالي البرامج" value={stats.total} color="text-emerald-600 dark:text-emerald-400" bg="bg-emerald-50 dark:bg-emerald-900/20" delay={0} />
              <StatCard icon={CheckCircle2} label="مكتملة" value={stats.completed} color="text-teal-600 dark:text-teal-400" bg="bg-teal-50 dark:bg-teal-900/20" delay={1} />
              <StatCard icon={Clock} label="قيد التنفيذ" value={stats.inProgress} color="text-amber-600 dark:text-amber-400" bg="bg-amber-50 dark:bg-amber-900/20" delay={2} />
              <StatCard icon={Building2} label="الأقسام" value={stats.departments} color="text-purple-600 dark:text-purple-400" bg="bg-purple-50 dark:bg-purple-900/20" delay={3} />
              <StatCard icon={TrendingUp} label="متوسط التقدم" value={stats.avgProgress} color="text-blue-600 dark:text-blue-400" bg="bg-blue-50 dark:bg-blue-900/20" delay={4} />
            </>
          ) : null}
        </div>

        {/* Quick Actions */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-gray-500/70 dark:text-gray-400/70 font-medium ml-0.5">إجراءات سريعة</span>
          {quickActions.map((action) => (
            <Button
              key={action.tab}
              variant="ghost"
              size="sm"
              onClick={() => setActiveTab(action.tab)}
              className={`h-8 px-3 text-xs gap-1.5 rounded-lg border ${action.bg} ${action.color} transition-all duration-200 group/qa`}
            >
              <action.icon className="size-3.5 transition-transform duration-200 group-hover/qa:scale-110 group-hover/qa:-translate-y-0.5" />
              <span className="hidden sm:inline">{action.label}</span>
              <ChevronLeft className="size-3 sm:hidden transition-transform duration-200 group-hover/qa:translate-x-0.5" />
            </Button>
          ))}
        </div>
      </div>
    </div>
  )
}
